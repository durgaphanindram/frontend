import { Routes } from '@angular/router';
import { WelcomeComponent } from './pages/welcome/welcome';
// import { DashboardComponent } from './pages/dashboard/dashboard';
import { DashboardComponent } from './pages/dashboard/dashboard';
import { WorkoutComponent } from './pages/workout/workout';
import { DietComponent } from './pages/diet/diet';

export const routes: Routes = [
  { path: '', component: WelcomeComponent },
  { path: 'dashboard', component: DashboardComponent },
  { path: 'workout', component: WorkoutComponent },
  { path: 'diet', component: DietComponent }
];

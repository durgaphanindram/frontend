import { Component } from '@angular/core';

@Component({
  selector: 'app-workout-day-card',
  imports: [],
  templateUrl: './workout-day-card.html',
  styleUrl: './workout-day-card.css',
})
export class WorkoutDayCard {

}

import { Component } from '@angular/core';

@Component({
  selector: 'app-metrics-card',
  imports: [],
  templateUrl: './metrics-card.html',
  styleUrl: './metrics-card.css',
})
export class MetricsCard {

}

import { Component } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-navbar',
  standalone: true,
  template: `
    <nav class="navbar">
      <span class="logo" (click)="goHome()">
        💪 AI Fitness Planner
      </span>

      <button ngIf="userId" class="logout" (click)="logout()">
        Logout
      </button>
    </nav>
  `,
  styles: [`
    .navbar {
      height: 64px;
      background: linear-gradient(90deg, #1e3c72, #2a5298);
      color: #ffffff;
      padding: 0 28px;
      display: flex;
      justify-content: space-between;
      align-items: center;
      box-shadow: 0 6px 18px rgba(0,0,0,0.15);
      position: sticky;
      top: 0;
      z-index: 100;
    }

    .logo {
      font-size: 20px;
      font-weight: 700;
      letter-spacing: 0.4px;
      cursor: pointer;
      user-select: none;
    }

    .logo:hover {
      opacity: 0.9;
    }

    .logout {
      background: #e74c3c;
      border: none;
      color: white;
      padding: 8px 14px;
      border-radius: 8px;
      font-size: 14px;
      font-weight: 600;
      cursor: pointer;
      transition: background 0.2s ease, transform 0.05s ease;
      box-shadow: 0 4px 10px rgba(0,0,0,0.2);
    }

    .logout:hover {
      background: #c0392b;
    }

    .logout:active {
      transform: translateY(1px);
    }

    @media (max-width: 600px) {
      .navbar {
        padding: 0 16px;
      }

      .logo {
        font-size: 18px;
      }

      .logout {
        padding: 7px 12px;
        font-size: 13px;
      }
    }
  `]
})
export class NavbarComponent {

  constructor(private router: Router) {}

  get userId() {
    return localStorage.getItem('user_id');
  }

  logout() {
    localStorage.clear();
    this.router.navigate(['/']);
  }

  goHome() {
    this.router.navigate(['/dashboard']);
  }
}

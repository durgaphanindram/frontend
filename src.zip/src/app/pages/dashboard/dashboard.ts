import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Router } from '@angular/router';
import { Metrics } from '../../core/models/metrics.model';

@Component({
  standalone: true,
  selector: 'app-dashboard',
  imports: [CommonModule],
  template: `
    <h2>📊 Your Health Dashboard</h2>

    <!-- METRICS SECTION (UNCHANGED) -->
    <div *ngIf="metrics" class="card metrics-card">
      <h3>Health Metrics</h3>

      <div class="grid">
        <div><b>BMI</b><span>{{ metrics.bmi }}</span></div>
        <div><b>BMR</b><span>{{ metrics.bmr }} kcal</span></div>
        <div>
          <b>Maintenance Calories</b>
          <span>{{ metrics.maintenance_calories }} kcal/day</span>
        </div>
        <div>
          <b>Water Intake</b>
          <span>{{ metrics.water_liters }} L/day</span>
        </div>
      </div>
    </div>

    <!-- ACTION BUTTONS -->
    <div class="card action-card">
      <h3>What would you like to do?</h3>

      <button class="btn workout" (click)="goToWorkout()">
        🏋️ View Workout Plan
      </button>

      <button class="btn diet" (click)="goToDiet()">
        🥗 View Diet Plan
      </button>
    </div>
  `,
  styles: [`
    .card {
      background: #ffffff;
      padding: 20px;
      margin-top: 15px;
      border-radius: 10px;
      box-shadow: 0 6px 15px rgba(0,0,0,0.1);
    }

    .metrics-card {
      border-left: 5px solid #2ecc71;
    }

    .grid {
      display: grid;
      grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
      gap: 14px;
      margin-top: 12px;
    }

    .grid div {
      background: #f5f7fb;
      padding: 14px;
      border-radius: 8px;
      text-align: center;
    }

    .action-card {
      text-align: center;
    }

    .btn {
      width: 100%;
      margin-top: 14px;
      padding: 14px;
      border-radius: 10px;
      border: none;
      font-size: 16px;
      font-weight: 600;
      cursor: pointer;
      color: white;
    }

    .btn.workout {
      background: #1e3c72;
    }

    .btn.diet {
      background: #27ae60;
    }

    .btn:hover {
      opacity: 0.9;
    }
  `]
})
export class DashboardComponent implements OnInit {

  metrics!: Metrics;

  constructor(private router: Router) {}

  ngOnInit() {
    const stored = localStorage.getItem('metrics');
    if (stored) {
      this.metrics = JSON.parse(stored);
    }
  }

  goToWorkout() {
    this.router.navigate(['/workout']);
  }

  goToDiet() {
    this.router.navigate(['/diet']);
  }
}

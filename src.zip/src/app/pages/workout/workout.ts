import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { ApiService } from '../../core/services/api';
import { WorkoutPlan } from '../../core/models/workout.model';
import { WorkoutTracking } from '../../core/models/tracking.model';

@Component({
  standalone: true,
  selector: 'app-workout',
  imports: [CommonModule, FormsModule],
  template: `
    <h2>🏋️ Weekly Workout Plan</h2>

    <!-- WORKOUT GENERATION FORM -->
    <div class="card">
      <form #f="ngForm" (ngSubmit)="generateWorkout(f)">
        
        <label>Goal</label>
        <select name="goal" ngModel="lose" required>
          <option value="lose">Lose Weight</option>
          <option value="maintain">Maintain</option>
          <option value="gain">Gain Muscle</option>
        </select>

        <button class="btn">
          {{ loading ? 'Generating...' : 'Generate Weekly Workout' }}
        </button>
      </form>
    </div>

    <!-- WORKOUT PLAN OUTPUT -->
    <div *ngIf="plan" class="card output">
      <h3>Week {{ plan.week }} Plan</h3>

      <div
        *ngFor="let d of plan.days"
        class="day-card"
      >
        <h4>Day {{ d.day }} – {{ d.focus }}</h4>
        <p class="duration">
          ⏱ Estimated Duration: {{ d.estimated_duration }} mins
        </p>

        <ul>
          <li *ngFor="let e of d.exercises">
            {{ e.name }} — {{ e.sets }} × {{ e.reps }}
          </li>
        </ul>

        <!-- TRACKING CONTROLS -->
        <div class="tracking">
          <button
            class="done"
            (click)="track(d.day, 'completed')"
          >
            ✔ Completed
          </button>

          <button
            class="partial"
            (click)="track(d.day, 'partially_completed')"
          >
            ⚠ Partial
          </button>

          <button
            class="skipped"
            (click)="track(d.day, 'skipped')"
          >
            ✖ Skipped
          </button>
        </div>
      </div>
    </div>
  `,
  styles: [`
    .card {
      background: #ffffff;
      padding: 20px;
      margin-top: 15px;
      border-radius: 10px;
      box-shadow: 0 6px 15px rgba(0,0,0,0.1);
    }

    label {
      display: block;
      margin-top: 10px;
      font-weight: bold;
    }

    select {
      width: 100%;
      padding: 10px;
      margin-top: 6px;
      border-radius: 8px;
      border: 1px solid #ccc;
    }

    .btn {
      width: 100%;
      margin-top: 16px;
      padding: 12px;
      background: #1e3c72;
      color: white;
      border: none;
      border-radius: 8px;
      font-size: 16px;
      cursor: pointer;
    }

    .btn:hover {
      background: #2c4d91;
    }

    .day-card {
      background: #f9fafc;
      padding: 15px;
      margin-top: 15px;
      border-radius: 8px;
      border-left: 5px solid #1e3c72;
    }

    .duration {
      font-size: 14px;
      color: #555;
    }

    ul {
      margin-top: 8px;
      padding-left: 18px;
    }

    .tracking {
      display: flex;
      gap: 8px;
      margin-top: 12px;
    }

    .tracking button {
      flex: 1;
      padding: 8px;
      border: none;
      border-radius: 6px;
      cursor: pointer;
      font-size: 14px;
    }

    .done {
      background: #2ecc71;
      color: white;
    }

    .partial {
      background: #f1c40f;
      color: #333;
    }

    .skipped {
      background: #e74c3c;
      color: white;
    }

    .tracking button:hover {
      opacity: 0.9;
    }
  `]
})
export class WorkoutComponent {
  plan: WorkoutPlan | null = null;
  loading = false;
  currentWeek = 1;

  constructor(private api: ApiService) {}

  generateWorkout(form: any) {
    this.loading = true;

    this.api.generateWorkout({
      user_id: localStorage.getItem('user_id')!,
      goal: form.value.goal,
      week: this.currentWeek
    }).subscribe(plan => {
      this.plan = plan;
      this.loading = false;
    });
  }

  track(day: number, status: 'completed' | 'partially_completed' | 'skipped') {
    const payload: WorkoutTracking = {
      user_id: localStorage.getItem('user_id')!,
      week: this.currentWeek,
      day,
      status
    };

    this.api.trackWorkout(payload).subscribe();
  }
}

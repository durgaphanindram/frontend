// import { Component } from '@angular/core';
// import { CommonModule } from '@angular/common';
// import { FormsModule } from '@angular/forms';
// import { Router } from '@angular/router';
// import { ApiService } from '../../core/services/api';
// import { Metrics } from '../../core/models/metrics.model';

// @Component({
//   standalone: true,
//   selector: 'app-welcome',
//   imports: [CommonModule, FormsModule],
//   templateUrl: './welcome.html',
//   styleUrls: ['./welcome.css']
// })
// export class WelcomeComponent {
//   metrics: Metrics | null = null;
//   loading = false;

//   constructor(private api: ApiService, private router: Router) {}

//   submit(form: any) {
//     this.loading = true;

//     this.api.createUser(form.value).subscribe(res => {
//       localStorage.setItem('user_id', res.user_id);
//       this.metrics = res.metrics;
//       this.loading = false;
//     });
//   }

//   continue() {
//     this.router.navigate(['/dashboard']);
//   }
// }

// ======================================================================
//=====================================================
import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { Router } from '@angular/router';
import { ApiService } from '../../core/services/api';
import { Metrics } from '../../core/models/metrics.model';

@Component({
  standalone: true,
  selector: 'app-welcome',
  imports: [CommonModule, FormsModule],
  template: `
    <div class="page">
      <h1>💪 AI Fitness Planner</h1>
      <p class="subtitle">
        Personalized workouts & diet plans powered by AI
      </p>

      <div class="card">
        <h3>Create Your Profile</h3>

        <form #f="ngForm" (ngSubmit)="submit(f)">
          
          <label>Name</label>
          <input name="name" ngModel placeholder="Your name" required />

          <label>Age</label>
          <input type="number" name="age" ngModel required />

          <label>Height (cm)</label>
          <input type="number" name="height" ngModel required />

          <label>Weight (kg)</label>
          <input type="number" name="weight" ngModel required />

          <label>Gender</label>
          <select name="gender" ngModel="male">
            <option value="male">Male</option>
            <option value="female">Female</option>
          </select>

          <!-- ✅ FIXED FIELD NAME -->
          <label>Activity Level</label>
          <select name="workout_intensity" ngModel="low">
            <option value="low">Low</option>
            <option value="medium">Medium</option>
            <option value="high">High</option>
          </select>

          <button class="btn">
            {{ loading ? 'Starting...' : 'Start My Fitness Plan' }}
          </button>
        </form>
      </div>
    </div>
  `,
  styles: [`
    .page {
      min-height: 100vh;
      display: flex;
      flex-direction: column;
      align-items: center;
      padding: 40px 16px;
    }

    h1 {
      color: #163d73;
      margin-bottom: 4px;
    }

    .subtitle {
      color: #555;
      margin-bottom: 24px;
    }

    .card {
      width: 100%;
      max-width: 720px;
      background: #fff;
      border-radius: 12px;
      padding: 24px;
      box-shadow: 0 8px 20px rgba(0,0,0,0.08);
    }

    label {
      display: block;
      margin-top: 14px;
      font-weight: 600;
    }

    input, select {
      width: 100%;
      padding: 12px;
      border-radius: 8px;
      border: 1px solid #d0d5dd;
    }

    .btn {
      width: 100%;
      margin-top: 22px;
      padding: 14px;
      border-radius: 10px;
      background: #1e3c72;
      color: white;
      font-weight: 600;
      border: none;
      cursor: pointer;
    }
  `]
})
export class WelcomeComponent {

  loading = false;

  constructor(
    private api: ApiService,
    private router: Router
  ) {}

  submit(form: any) {
    this.loading = true;

    this.api.createUser(form.value).subscribe(res => {
      // ✅ Store data
      localStorage.setItem('user_id', res.user_id);
      localStorage.setItem('metrics', JSON.stringify(res.metrics));

      // ✅ NAVIGATE TO DASHBOARD
      this.router.navigate(['/dashboard']);
    });
  }
}

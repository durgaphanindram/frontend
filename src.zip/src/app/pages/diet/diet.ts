import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { ApiService } from '../../core/services/api';
import { DietPlan } from '../../core/models/diet.model';

@Component({
  standalone: true,
  selector: 'app-diet',
  imports: [CommonModule, FormsModule],
  template: `
    <h2>🥗 Diet Plan</h2>

    <!-- DIET FORM -->
    <div class="card">
      <form #f="ngForm" (ngSubmit)="generateDiet(f)">
        
        <label>Goal</label>
        <select name="goal" ngModel required>
          <option value="lose">Lose Weight</option>
          <option value="maintain">Maintain</option>
          <option value="gain">Gain Weight</option>
        </select>

        <label>Dietary Preference</label>
        <select name="dietary_preference" ngModel required>
          <option value="veg">Vegetarian</option>
          <option value="non-veg">Non-Vegetarian</option>
          <option value="vegan">Vegan</option>
        </select>

        <label>Allergies (optional)</label>
        <input
          type="text"
          name="allergies"
          ngModel
          placeholder="e.g. peanuts, dairy"
        />

        <button class="btn">
          {{ loading ? 'Generating...' : 'Generate Diet Plan' }}
        </button>
      </form>
    </div>

    <!-- DIET OUTPUT -->
    <div *ngIf="plan" class="card output">
      <h3>Weekly Diet Plan</h3>

      <div *ngFor="let d of plan.meals">
        <h4>Day {{ d.day }}</h4>
        <p><b>Breakfast:</b> {{ d.breakfast }}</p>
        <p><b>Lunch:</b> {{ d.lunch }}</p>
        <p><b>Dinner:</b> {{ d.dinner }}</p>
        <p><b>Snacks:</b> {{ d.snacks }}</p>
        <hr />
      </div>
    </div>
  `,
  styles: [`
    .card {
      background: #fff;
      padding: 20px;
      margin-top: 15px;
      border-radius: 10px;
      box-shadow: 0 6px 15px rgba(0,0,0,0.1);
    }

    label {
      display: block;
      margin-top: 12px;
      font-weight: bold;
    }

    input, select {
      width: 100%;
      padding: 10px;
      margin-top: 6px;
      border-radius: 8px;
      border: 1px solid #ccc;
    }

    .btn {
      width: 100%;
      margin-top: 18px;
      padding: 12px;
      background: #1e3c72;
      color: white;
      border: none;
      border-radius: 8px;
      font-size: 16px;
      cursor: pointer;
    }

    .btn:hover {
      background: #2c4d91;
    }

    .output h4 {
      margin-top: 12px;
    }
  `]
})
export class DietComponent {
  plan: DietPlan | null = null;
  loading = false;

  constructor(private api: ApiService) {}

  generateDiet(form: any) {
    this.loading = true;

    this.api.generateDiet({
      user_id: localStorage.getItem('user_id')!,
      goal: form.value.goal,
      dietary_preference: form.value.dietary_preference,
      allergies: form.value.allergies
    }).subscribe(plan => {
      this.plan = plan;
      this.loading = false;
    });
  }
}

import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { User } from '../models/user.model';
import { WorkoutPlan } from '../models/workout.model';
import { DietPlan } from '../models/diet.model';
import { WorkoutTracking } from '../models/tracking.model';

@Injectable({ providedIn: 'root' })
export class ApiService {
  private BASE = 'http://127.0.0.1:8000';

  constructor(private http: HttpClient) {}

  createUser(data: Partial<User>) {
    return this.http.post<{
      user_id: string;
      metrics: {
        bmi: number;
        bmr: number;
        maintenance_calories: number;
        water_liters: number;
      };
    }>(`${this.BASE}/users/create`, data);
  }

  getUser(userId: string) {
    return this.http.get<User>(`${this.BASE}/users/${userId}`);
  }

  generateWorkout(data: { user_id: string; goal: string; week: number }) {
    return this.http.post<WorkoutPlan>(
      `${this.BASE}/plans/workout`,
      data
    );
  }

  generateDiet(data: {
    user_id: string;
    goal: string;
    dietary_preference: string;
    allergies?: string;
  }) {
    return this.http.post<DietPlan>(
      `${this.BASE}/plans/diet`,
      data
    );
  }

  trackWorkout(data: WorkoutTracking) {
    return this.http.post(`${this.BASE}/workouts/track`, data);
  }
}

export interface Metrics {
  bmi: number;
  bmr: number;
  maintenance_calories: number;
  water_liters: number;
}

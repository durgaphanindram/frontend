export type WorkoutStatus =
  | 'completed'
  | 'partially_completed'
  | 'skipped';

export type DifficultyLevel =
  | 'easy'
  | 'normal'
  | 'hard';

export interface WorkoutTracking {
  user_id: string;
  week: number;
  day: number;
  status: WorkoutStatus;
  difficulty?: DifficultyLevel;
  notes?: string;
}

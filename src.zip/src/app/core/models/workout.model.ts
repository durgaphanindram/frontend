export interface WorkoutExercise {
  name: string;
  sets: number;
  reps: number;
}

export interface WorkoutDay {
  day: number;                // Day 1, Day 2, ...
  focus: string;              // Full Body, Upper Body, etc.
  estimated_duration: number; // minutes
  exercises: WorkoutExercise[];
}

export interface WorkoutPlan {
  week: number;
  days: WorkoutDay[];
}

export interface User {
  user_id: string;
  name: string;
  age: number;
  height: number;
  weight: number;
  gender: 'male' | 'female';
  activity_level: 'low' | 'medium' | 'high';

  bmi: number;
  bmr: number;
  maintenance_calories: number;
  water_liters: number;

  created_at: string;
}

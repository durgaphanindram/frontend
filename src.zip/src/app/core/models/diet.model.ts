export interface DietDay {
  day: number;
  breakfast: string;
  lunch: string;
  dinner: string;
  snacks: string;
}

export interface DietPlan {
  daily_calories: number;
  meals: DietDay[];
}
